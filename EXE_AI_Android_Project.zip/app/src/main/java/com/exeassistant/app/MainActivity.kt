package com.exeassistant.app

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF090B10)
private val Panel = Color(0xFF131722)
private val Accent = Color(0xFF7C5CFF)
private val Txt = Color(0xFFF2F3F8)
private val Muted = Color(0xFF9AA3B5)

data class ChatLine(val fromUser: Boolean, val text: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var input by remember { mutableStateOf("") }
            var lines by remember {
                mutableStateOf(listOf(ChatLine(false,
                    "Ben EXE. Şimdilik temel cihaz komutlarını ve sohbeti destekleyen başlangıç sürümüyüm. Ne yapmamı istersin?")))
            }
            MaterialTheme(colorScheme = darkColorScheme(
                background = Bg, surface = Panel, primary = Accent,
                onBackground = Txt, onSurface = Txt
            )) {
                Column(
                    Modifier.fillMaxSize().background(Bg).padding(18.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(42.dp).background(Accent, RoundedCornerShape(14.dp)),
                            contentAlignment = Alignment.Center) {
                            Text("X", fontSize = 23.sp, fontWeight = FontWeight.Black, color = Color.White)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("EXE AI", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Txt)
                            Text("KİŞİSEL ASİSTAN • ANDROID", fontSize = 10.sp, color = Muted, letterSpacing = 1.2.sp)
                        }
                        Box(Modifier.size(8.dp).background(Color(0xFF53E6A5), RoundedCornerShape(50)))
                    }
                    Spacer(Modifier.height(22.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        QuickCard("Cihaz komutları", "İzinle çalışır", Modifier.weight(1f))
                        QuickCard("Gizlilik", "Kontrol sende", Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(14.dp))
                    Text("SOHBET", fontSize = 11.sp, color = Muted, letterSpacing = 1.5.sp)
                    Spacer(Modifier.height(8.dp))
                    LazyColumn(
                        modifier = Modifier.weight(1f).fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(lines) { line ->
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = if (line.fromUser) Arrangement.End else Arrangement.Start
                            ) {
                                Text(
                                    line.text,
                                    modifier = Modifier.widthIn(max = 300.dp)
                                        .background(if (line.fromUser) Accent.copy(alpha = .22f) else Panel,
                                            RoundedCornerShape(16.dp))
                                        .padding(14.dp),
                                    color = Txt, fontSize = 15.sp, lineHeight = 21.sp
                                )
                            }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        BasicTextField(
                            value = input, onValueChange = { input = it },
                            modifier = Modifier.weight(1f).background(Panel, RoundedCornerShape(16.dp)).padding(15.dp),
                            textStyle = androidx.compose.ui.text.TextStyle(color = Txt, fontSize = 15.sp),
                            singleLine = true,
                            decorationBox = { inner ->
                                Box {
                                    if (input.isEmpty()) Text("EXE'ye komut yaz...", color = Muted)
                                    inner()
                                }
                            }
                        )
                        Spacer(Modifier.width(8.dp))
                        Button(
                            onClick = {
                                val command = input.trim()
                                if (command.isNotEmpty()) {
                                    lines = lines + ChatLine(true, command) +
                                        ChatLine(false, runCommand(command))
                                    input = ""
                                }
                            },
                            shape = RoundedCornerShape(14.dp),
                            contentPadding = PaddingValues(horizontal = 18.dp, vertical = 15.dp)
                        ) { Text("Gönder", fontWeight = FontWeight.Bold) }
                    }
                    Spacer(Modifier.height(10.dp))
                    OutlinedButton(
                        onClick = { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp)
                    ) { Text("Cihaz kontrol izinlerini aç", color = Txt) }
                    Text(
                        "Güvenlik: EXE izinsiz işlem yapmaz. Önemli işlemleri kendin onayla.",
                        color = Muted, fontSize = 11.sp, lineHeight = 15.sp,
                        modifier = Modifier.padding(top = 9.dp)
                    )
                }
            }
        }
    }

    private fun runCommand(raw: String): String {
        val s = raw.lowercase()
        return when {
            "ayarlar" in s -> {
                startActivity(Intent(Settings.ACTION_SETTINGS))
                "Android Ayarları açılıyor."
            }
            "erişilebilirlik" in s || "izin" in s -> {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                "Erişilebilirlik ayarlarını açıyorum. İzni yalnızca ne yaptığını anladıktan sonra etkinleştir."
            }
            "saat" in s || "tarih" in s -> "Cihaz saatini kontrol etmek için Android durum çubuğuna bakabilirsin."
            "yardım" in s || "ne yap" in s -> "Bu başlangıç sürümünde 'ayarları aç', 'izinler' veya 'yardım' komutlarını deneyebilirsin. Serbest biçimli akıllı yapay zekâ için ayrıca güvenli bir AI sunucusu/API bağlantısı gerekir."
            else -> "Bu komut için henüz bir işlem tanımlı değil. Bu sürüm gerçek bir çevrim içi yapay zekâya bağlı değil; cihazındaki her şeyi kontrol ediyormuş gibi davranmaz."
        }
    }
}

@Composable
private fun QuickCard(title: String, subtitle: String, modifier: Modifier = Modifier) {
    Column(modifier.background(Panel, RoundedCornerShape(16.dp)).padding(13.dp)) {
        Text(title, color = Txt, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        Spacer(Modifier.height(4.dp))
        Text(subtitle, color = Muted, fontSize = 11.sp)
    }
}
