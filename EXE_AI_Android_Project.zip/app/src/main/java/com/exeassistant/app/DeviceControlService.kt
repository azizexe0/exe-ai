package com.exeassistant.app

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

/**
 * Başlangıç iskeleti. Gerçek komut yürütme burada henüz uygulanmamıştır.
 * Kullanıcı onayı olmadan ekranlara tıklama veya hassas içerik okuma eklemeyin.
 */
class DeviceControlService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Bilerek boş: ekran içeriği izlenmez.
    }

    override fun onInterrupt() {
        // Android erişilebilirlik servis kesintisi.
    }
}
