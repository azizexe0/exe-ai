# EXE AI — Android başlangıç projesi

Bu paket **derlenmiş APK değildir**; Android Studio ile APK üretmek için hazırlanmış kaynak projedir.
Bu çalışma ortamında Android SDK/Gradle kurulu olmadığı için imzalı veya kurulabilir APK derlenemedi.

## İçindekiler
- Koyu temalı EXE AI sohbet arayüzü
- Temel örnek komutlar: Android Ayarları ve Erişilebilirlik ayarlarını açma
- Erişilebilirlik servisi için başlangıç iskeleti
- Harici sunucuya/API'ye bağlı olmayan demo yanıtlar

## APK oluşturma
1. Bilgisayarda Android Studio'yu kur.
2. Android Studio'da **Open** seçip bu klasörü aç.
3. Gradle senkronizasyonunun bitmesini bekle.
4. **Build > Build APK(s)** seç.
5. APK genellikle `app/build/outputs/apk/debug/app-debug.apk` konumunda oluşur.

## Önemli sınırlar
- Bu sürüm genel amaçlı yapay zekâ değildir ve internete bağlı değildir.
- Telefonun tamamını sessizce kontrol etmez. Android, birçok işlem için kullanıcı izni/onayı gerektirir.
- Gerçek bir AI için API anahtarını APK içine koyma. Bir sunucu üzerinden güvenli bağlantı kur.
- Erişilebilirlik izni güçlüdür; yalnızca güvendiğin uygulamalara ver.
- `DeviceControlService` temel iskelettir; henüz komutları dokunma hareketlerine çevirecek şekilde uygulanmamıştır.
